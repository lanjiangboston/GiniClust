# work directory
workdir = getwd() 
setwd(workdir)
if(!file.exists('Library')){
  dir.create('Library')
}
.libPaths(c(paste(workdir,'/Library',sep=""),.libPaths()))

if (!suppressWarnings(require("optparse",quietly = TRUE))) {
  install.packages("optparse",dependencies = TRUE, repos="http://cran.r-project.org")
}
library(optparse,quietly = TRUE)

option_list = list(
  make_option(c("-f", "--file"), type="character", default=NULL, 
              help="input dataset file name", metavar="character"),
  make_option(c("-t", "--type"), type="character", default=NULL, 
              help="input dataset type: choose from 'qPCR' or 'RNA-seq' ", metavar="character"),  
  make_option(c("-o", "--out"), type="character", default="results", 
              help="output folder name [default= %default]", metavar="character")
)
opt_parser = OptionParser(option_list=option_list)
opt = parse_args(opt_parser)

if (is.null(opt$file)){
  print_help(opt_parser)
  stop("Input dataset file name must be supplied", call.=FALSE)
}else if (is.null(opt$type)){
  print_help(opt_parser)
  stop("Input dataset type must be supplied", call.=FALSE)
}else if (!(opt$type %in% c('qPCR','RNA-seq'))){
  print_help(opt_parser)
  stop("Input dataset type must be chosen from 'qPCR' or 'RNA-seq' ", call.=FALSE)
}
  

data.file = opt$file
data.type = opt$type
out.folder = opt$out


#GiniClust
exprimentID = substr(data.file,1,nchar(data.file)-4)
source("Rfunction/GiniClust_parameters.R")
source("Rfunction/GiniClust_packages.R")
source("Rfunction/GiniClust_functions.R")
source("Rfunction/GiniClust_PreProcess.R")
source("Rfunction/GiniClust_filtering_RawCounts.R")
source("Rfunction/GiniClust_fitting.R")
source("Rfunction/GiniClust_clustering.R")
source("Rfunction/GiniClust_tSNE.R")

#check the clustering results
table(c_membership)
print(rare.cells.list.all)

#DE
if(data.type == 'RNA-seq'){
  source("Rfunction/DE_MAST.R")
  source("Rfunction/DE_MAST.figures.R")
}
if(data.type == 'qPCR'){
  source("Rfunction/DE_t-test.R")
}

