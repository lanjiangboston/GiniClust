#fixed parameters for all dataset:
minCellNum           = 3                                                # filtering, for at least expressed in how many cells
minGeneNum           = 2000                                             # filtering, for at least expressed in how many genes
expressed_cutoff     = 1                                                # filtering, for raw counts
gini.bi              = 0                                                # fitting, default is 0, for qPCR data, set as 1. 
log2.expr.cutoffl    = 0                                                # cutoff for range of gene expression   
log2.expr.cutoffh    = 20                                               # cutoff for range of gene expression 
Gini.pvalue_cutoff   = 0.0001                                           # fiting, Pvalue, control how many gene finally used.
Norm.Gini.cutoff     = 1                                                # fiting, NomGini, control how many gene finally used, 1 means not used.
span                 = 0.9                                              # parameter for LOESS fitting
outlier_remove       = 0.75                                             # parameter for LOESS fitting
GeneList             = 1                                                # parameter for clustering, 1 means using pvalue, 0 means using HighNormGini
Gamma                = 0.9                                              # parameter for clustering
eps                  = 0.5                                              # parameter for DBSCAN
MinPts               = 3                                                # parameter for DBSCAN
mycols               = c("grey50","greenyellow","red","blue","black")   # color setting for tSNE plot
diff.cutoff          = 1                                                # MAST analysis, filter gene don't have high log2_foldchange to reduce gene num
lr.p_value_cutoff    = 1e-5                                             # MAST analysis, pvalue cutoff to identify differential expressed gene
CountsForNormalized  = 100000                                           # not used
rare_p               = 0.05                                             # propostion of cell number < this value will be considered as rare cell clusters.
perplexity           = 30
Rfundir              = "/Users/lanjiang/upload2github/GiniClust_V1/Rfunction/" 



#dataset specific parameters:
workdir              = "/Users/lanjiang/upload2github/GiniClust_V1/Proj/inDrop/"  # where you put the data and results
GeneList.final       = Genelist.top_pvalue
exprimentID          = "d0t1"                                                    # experiment or data set ID


#Pre Processing the data
setwd(workdir)
source(paste(Rfundir,"PreProcess_for_inDrop.R",sep=""))




#GiniClust
source(paste(Rfundir,"GiniClust_packages.R",sep=""))
source(paste(Rfundir,"GiniClust_functions.R",sep=""))
source(paste(Rfundir,"GiniClust_filtering_RawCounts.R",sep=""))
source(paste(Rfundir,"GiniClust_fitting.R",sep=""))
source(paste(Rfundir,"GiniClust_clustering_RNAseq.R",sep=""))
source(paste(Rfundir,"GiniClust_tSNE.R",sep=""))
#check the clustering results
table(c_membership)
print(rare.cells.list.all)
#DE
source(paste(Rfundir,"DE_MAST.R",sep=""))
source(paste(Rfundir,"DE_MAST.figures.R",sep=""))


# resampling the non-rare cells to estimate whether the cluster results are robust.
# if(!file.exists("ReSamping")){
#   dir.create("ReSamping")
# }
# source(paste(Rfundir,"GiniClust_resampling.R",sep=""))
# setwd(workdir)


#save the session
library("session")
save.session(paste("results/", exprimentID, "_", format(Sys.time(), "%b%d"),".session",sep=""))
#restore.session("")





