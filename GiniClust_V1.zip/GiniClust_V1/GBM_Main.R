#fixed parameters for all dataset:
workdir              = "/Users/lanjiang/Work.YuanLab/GiniClust_V1/"     # where you put the data and results
minCellNum           = 3                                                # filtering, for at least expressed in how many cells
minGeneNum           = 2000                                             # filtering, for at least expressed in how many genes
expressed_cutoff     = 1                                                # filtering, for raw counts
log2.expr.cutoffl    = 0                                                # cutoff for range of gene expression   
log2.expr.cutoffh    = 20                                               # cutoff for range of gene expression 
Gini.pvalue_cutoff   = 0.0001                                           # fiting, Pvalue, control how many gene finally used.
x.cutl               = 0.25                                             # fiting, control how many genes will be choosed for fitting  
x.cuth               = 0.75                                             # fiting, control how many genes will be choosed for fitting
eps                  = 0.5                                              # parameter for DBSCAN
MinPts               = 3                                                # parameter for DBSCAN
mycols               = c("grey50","greenyellow","red","blue","black")   # color setting for tSNE plot
diff.cutoff          = 1                                                # MAST analysis, filter gene don't have high log2_foldchange to reduce gene num
lr.p_value_cutoff    = 1e-5                                             # MAST analysis, pvalue cutoff to identify differential expressed gene


#dataset specific parameters:
exprimentID           = "Patel"                              # experiment or data set ID
CountsForNormalized   = 1000000                              # denominator for normalization of counts, which is depended on median of sum(counts) of all cells
file_pre=paste(format(Sys.time(), "%b%d"),exprimentID,x.cutl,x.cuth,Gini.pvalue_cutoff,sep="_")


setwd(paste(workdir,"/GBM/",sep=""))
#Pre Process the data
source("../Rfunction/PreProcess_for_GBM.R")

#GiniClust
source("../Rfunction/GiniClust_packages.R")
source("../Rfunction/GiniClust_functions.R")
source("../Rfunction/GiniClust_filtering_RawCounts.R")          
source("../Rfunction/GiniClust_fit_drm_RawCounts.R") 
source("../Rfunction/GiniClust_clustering.R")

#check the clustering results
print(table(c_membership))
print(rare.cells.list.all)

#identify DE for all rare cell types
source("../Rfunction/DE_MAST.R")
source("../Rfunction/DE_MAST.figures.R")

#save the session
#library("session")
save.session(paste("results/", exprimentID, "_", format(Sys.time(), "%b%d"),".session",sep=""))
#restore.session("")

