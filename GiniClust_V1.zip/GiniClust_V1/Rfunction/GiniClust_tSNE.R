# .4 visulization using tsne 
seed = 10
set.seed(seed)                     # Set a seed if you want reproducible results
Rtsne_map <- Rtsne(cell.cell.jaccard.distance, is_distance = TRUE, pca = TRUE,  max_iter = 2000, perplexity = perplexity)       
pdf(file=paste("figures/Figures_", exprimentID, "_perplexity_", perplexity, "_tsne_plot_jaccard_c_membership.pdf", sep=""), width = 8, height =8, useDingbats = FALSE)
plot(Rtsne_map$Y,col=mycols[as.integer(c_membership)], pch=16, xlab="Dimension_1", ylab="Dimension_2", cex=1, main="")
legend('topleft',levels(as.factor(c_membership)),fill=mycols, bty='n', cex=1.5)
dev.off() 


# .5 save results
Rtnse_coord2 <-  as.data.frame(Rtsne_map$Y)
rownames(Rtnse_coord2) = rownames(cell.cell.jaccard.distance)
colnames(Rtnse_coord2) = c("dim1", "dim2")
write.table(Rtnse_coord2, file=paste("results/", exprimentID,"_Rtnse_coord2.csv", sep=""), sep=",", row.names = TRUE, col.names = TRUE)
