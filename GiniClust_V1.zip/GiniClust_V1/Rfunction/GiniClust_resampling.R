

setwd(paste(workdir,"/ReSamping/",sep=""))

if(!file.exists("data")){
  dir.create("data")
}
if(!file.exists("results")){
  dir.create("results")
}
if(!file.exists("figures")){
  dir.create("figures")
}



rare.cluster.name   = as.character(cluster_stat[dim(cluster_stat)[1],]$c_membership) #get the cluster ID of smallest cluster
non_rare_cell.list  = as.character(clustering_membership_r[clustering_membership_r$cluster.ID != rare.cluster.name,]$cell.ID)
rare_cell.list      = as.character(clustering_membership_r[clustering_membership_r$cluster.ID == rare.cluster.name,]$cell.ID)
non_rare_cell.ExprM = ExprM.RawCounts.filter[, non_rare_cell.list]
rare_cell.ExprM     = ExprM.RawCounts.filter[, rare_cell.list]
dim(non_rare_cell.ExprM)
dim(rare_cell.ExprM)
file_pre=exprimentID
for(prop in c(0.9, 0.8, 0.7, 0.6, 0.5)){
  # direct output to a file 
  sink(paste("prop_",prop,"_non_rare_cell_sampling_Ginicluster_reprot.txt",sep=""), append=FALSE, split=FALSE)
  #sampling 90% non rare cells.
  for(sss in 1:10){
    set.seed(sss)
    new_cell_num = round(dim(non_rare_cell.ExprM)[2] * prop)
    new_cell_set = sample(1:dim(non_rare_cell.ExprM)[2], new_cell_num)
    ExprM.RawCounts.filter = cbind(non_rare_cell.ExprM[, new_cell_set], rare_cell.ExprM)
    save(ExprM.RawCounts.filter, file=paste("results/", exprimentID, "_ExprM.filter.RData", sep=""))
    dim(ExprM.RawCounts.filter) #22432  2236
    source(paste(Rfundir,"GiniClust_fitting.R",sep=""))
    source(paste(Rfundir,"GiniClust_clustering_RNAseq.R",sep=""))
    #check the clustering results
    print(sss)
    print(head(new_cell_set))
    print(table(c_membership))
    print(rare.cells.list.all)
  }
  
}


