#########################################################
### C) download data and preprocess 
#########################################################
#data process before GINICLUST

#expression_mRNA_17-Aug-2014.txt downloaded from http://linnarssonlab.org/blobs/cortex/expression_mRNA_17-Aug-2014.txt
#wget didn't work
#can also download using 
#system("wget ftp://ftp.ncbi.nlm.nih.gov/geo/series/GSE60nnn/GSE60361/suppl/GSE60361_C1-3005-Expression.txt.gz -P data/")
#system("gunzip data/GSE60361_C1-3005-Expression.txt.gz")
#but, without BackSpin results information 

########### load Anno data #########
Anno <- read.delim("data/expression_mRNA_17-Aug-2014.txt",head=TRUE, sep="\t", row.names=NULL)
dim(Anno) #19982  3007
level1class <- make.unique(as.character(t(unlist(Anno[8,3:3007]))))
extract.field=function(string,field,delim) return(strsplit(string,delim)[[1]][field])
cell.labels = factor(unlist(lapply(level1class,extract.field,1,"\\.")))
groups <- factor(cell.labels,levels=levels(cell.labels))
table(groups)
table(as.character(unname(unlist(Anno[9,]))))
level1class[which(groups=="pyramidal CA1")] = "pyramidal_CA1"
level1class[which(groups=="pyramidal SS")]  = "pyramidal_SS"
level1class[which(groups=="endothelial-mural")]  = "endothelial_mural"
level1class <- make.unique(level1class)
extract.field=function(string,field,delim) return(strsplit(string,delim)[[1]][field])
cell.labels = factor(unlist(lapply(level1class,extract.field,1,"\\.")))
groups <- factor(cell.labels,levels=levels(cell.labels))
table(groups)
# level1.stat <- table(cell.labels)
# levels(cell.labels)
# length(cell.labels)

ExprM.RawCounts = Anno[11:19982,3:3007]
colnames(ExprM.RawCounts) = level1class;
#rownames(ExprM.RawCounts) = Anno[11:19982,1]
rownames(ExprM.RawCounts) = make.unique(as.character(t(unlist(Anno[11:19982,1]))))
dim(ExprM.RawCounts)  #19972  3005
#class of the dataframe is factor, write and read will make it be numeric.
write.table(ExprM.RawCounts, file=paste("results/", exprimentID, "_rawCounts.csv", sep=""), sep=",", row.names = TRUE, col.names = TRUE, quote=FALSE)
ExprM.RawCounts = read.delim(paste("results/", exprimentID, "_rawCounts.csv", sep=""), head=TRUE, sep=",")
colsum <- apply(ExprM.RawCounts,2,sum)
median(colsum)  #[1] 12089
ExprM.normCounts <- t(t(ExprM.RawCounts)*CountsForNormalized/colsum)
# ############ filter low expressed gene, why ############## 
# UMISUM <- apply(data.clean,1,sum)
# data.Filter.LowExpressed <- data.UMIPM[UMISUM>24,] #note , this is NOT in UMIPM scale
# dim(data.Filter.LowExpressed)
# 
# #[1] 15251  3005 
# #their cell have already be filtered, so only gene num decrease....
# write.table(data.Filter.LowExpressed, file="data/CerebralCortex.Filtered.UMIPM.csv", sep=",", row.names = TRUE, col.names = TRUE, quote=FALSE)
write.table(ExprM.RawCounts, file=paste("results/", exprimentID, "_rawCounts.csv", sep=""), sep=",", row.names = TRUE, col.names = TRUE, quote=FALSE)
write.table(ExprM.normCounts, file=paste("results/", exprimentID, "_normCounts.csv", sep=""), sep=",", row.names = TRUE, col.names = TRUE, quote=FALSE)
save(ExprM.RawCounts, ExprM.normCounts, file=paste("results/",exprimentID, "_ExprM.RData",sep=""))







