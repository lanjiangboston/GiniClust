#########################################################
### C) download data and preprocess 
#########################################################
#data process before GINICLUST

#note:
#expression_mRNA_17-Aug-2014.txt downloaded from http://linnarssonlab.org/blobs/cortex/expression_mRNA_17-Aug-2014.txt
#wget didn't work
#can also download using 
#system("wget ftp://ftp.ncbi.nlm.nih.gov/geo/series/GSE60nnn/GSE60361/suppl/GSE60361_C1-3005-Expression.txt.gz -P data/")
#system("gunzip data/GSE60361_C1-3005-Expression.txt.gz")
#but, without BackSpin results information 

########### load dataset which contain BackSPIN Annotation #########
Anno <- read.delim("data/expression_mRNA_17-Aug-2014.txt",head=TRUE, sep="\t", row.names=NULL)
dim(Anno) #19982  3007
level1class <- make.unique(as.character(t(unlist(Anno[8,3:3007]))))
extract.field=function(string,field,delim) return(strsplit(string,delim)[[1]][field])
cell.labels = factor(unlist(lapply(level1class,extract.field,1,"\\.")))
groups <- factor(cell.labels,levels=levels(cell.labels))
table(groups)
table(as.character(unname(unlist(Anno[9,]))))
level1class[which(groups=="pyramidal CA1")] = "pyramidal_CA1"
level1class[which(groups=="pyramidal SS")]  = "pyramidal_SS"
level1class[which(groups=="endothelial-mural")]  = "endothelial_mural"
level1class <- make.unique(level1class)
extract.field=function(string,field,delim) return(strsplit(string,delim)[[1]][field])
cell.labels = factor(unlist(lapply(level1class,extract.field,1,"\\.")))
groups <- factor(cell.labels,levels=levels(cell.labels))
table(groups)


ExprM.RawCounts = Anno[11:19982,3:3007]
colnames(ExprM.RawCounts) = level1class;
rownames(ExprM.RawCounts) = make.unique(as.character(t(unlist(Anno[11:19982,1]))))
dim(ExprM.RawCounts)  #19972  3005
write.table(ExprM.RawCounts, file=paste("results/", exprimentID, "_rawCounts.csv", sep=""), sep=",", row.names = TRUE, col.names = TRUE, quote=FALSE)
ExprM.RawCounts = read.delim(paste("results/", exprimentID, "_rawCounts.csv", sep=""), head=TRUE, sep=",")
colsum <- apply(ExprM.RawCounts,2,sum)
median(colsum)  #[1] 12089
ExprM.normCounts <- t(t(ExprM.RawCounts)*CountsForNormalized/colsum)
write.table(ExprM.RawCounts, file=paste("results/", exprimentID, "_rawCounts.csv", sep=""), sep=",", row.names = TRUE, col.names = TRUE, quote=FALSE)
write.table(ExprM.normCounts, file=paste("results/", exprimentID, "_normCounts.csv", sep=""), sep=",", row.names = TRUE, col.names = TRUE, quote=FALSE)
save(ExprM.RawCounts, ExprM.normCounts, file=paste("results/",exprimentID, "_ExprM.RData",sep=""))

