#########################################################
### G) binarization, jaccard distance, dbscan for clustering
#########################################################
#parameters
#perplexity
#eps 
#MinPts
#update3.4, using unfiltered raw counts as input


# .1 load data
load(paste("results/", exprimentID,"_StatisticsTable_afterLOESS.RData",sep=""))  #"Genelist.top_pvalue" "ExprM.Stat2" 
load(paste("results/", exprimentID,"_ExprM.filter.RData", sep=""))  #"ExprM.RawCounts.filter"  "ExprM.normCounts.filter"
load(paste("results/", exprimentID,"_ExprM.RData", sep=""))  #"ExprM.RawCounts.filter"  "ExprM.normCounts.filter"
dim(ExprM.RawCounts)            
dim(ExprM.RawCounts.filter)     

# .2 binarization
value.cutoff = 0
GeneList.final = Genelist.top_pvalue
m = ExprM.RawCounts.filter[GeneList.final,]
m2 = m
bc.list = c()
for(rn in 1:dim(m)[1])
{
  rd <- as.numeric(m[rn,])
  bc <- mean(rd[rd>value.cutoff])
  rd[rd<=bc]=0
  rd[rd>bc]=1  
  m2[rn,] = rd
  bc.list[rn] = bc
  #rd[rd>0]
}
RawCounts_cutoff = mean(bc.list[1:length(bc.list)*0.05])
all.gene.as.col.ExprM.RawCounts.binary = t(ExprM.RawCounts.filter)
all.gene.as.col.ExprM.RawCounts.binary[all.gene.as.col.ExprM.RawCounts.binary <  RawCounts_cutoff] = 0
all.gene.as.col.ExprM.RawCounts.binary[all.gene.as.col.ExprM.RawCounts.binary >= RawCounts_cutoff] = 1
final.gene.as.col.ExprM.RawCounts.binary = all.gene.as.col.ExprM.RawCounts.binary[, GeneList.final]
dim(final.gene.as.col.ExprM.RawCounts.binary) 

# .3 jaccard distance matrix
# #remove cells, which have all 0
# row.sum                              = apply(final.gene.as.col.ExprM.RawCounts.binary, 1, sum ) #row.sum
# final.gene.as.col.ExprM.RawCounts.binary = final.gene.as.col.ExprM.RawCounts.binary[row.sum > 0, ]
# dim(final.gene.as.col.ExprM.RawCounts.binary) 
# #remove genes which have all 0
# col.sum                              = apply(t(final.gene.as.col.ExprM.RawCounts.binary), 1, sum)
# final.gene.as.col.ExprM.RawCounts.binary = final.gene.as.col.ExprM.RawCounts.binary[, col.sum > 0]
# dim(final.gene.as.col.ExprM.RawCounts.binary)
# cell.cell.jaccard.distance            = vegdist(final.gene.as.col.ExprM.RawCounts.binary, method = "jaccard")
# cell.cell.jaccard.distance            = as.data.frame(as.matrix(cell.cell.jaccard.distance))
# rownames(cell.cell.jaccard.distance)  = rownames(final.gene.as.col.ExprM.RawCounts.binary)
# colnames(cell.cell.jaccard.distance)  = rownames(final.gene.as.col.ExprM.RawCounts.binary)
# dim(cell.cell.jaccard.distance)


###------------------------------- Complementary codes -------------------------------###
#locate cells whose gene expression values are all zeros
index.cell.zero = which(apply(final.gene.as.col.ExprM.RawCounts.binary,1,function(x) length(which(x>0)))==0)
cell.cell.jaccard.distance = 1 - jaccard(final.gene.as.col.ExprM.RawCounts.binary)
cell.cell.jaccard.distance = as.data.frame(as.matrix(cell.cell.jaccard.distance))
#covert distance between two 'zero cells' to zero
cell.cell.jaccard.distance[index.cell.zero,index.cell.zero] = 0
cell.cell.jaccard.distance            = as.data.frame(as.matrix(cell.cell.jaccard.distance))
rownames(cell.cell.jaccard.distance)  = rownames(final.gene.as.col.ExprM.RawCounts.binary)
colnames(cell.cell.jaccard.distance)  = rownames(final.gene.as.col.ExprM.RawCounts.binary)
dim(cell.cell.jaccard.distance)
###-----------------------------------------------------------------------------------###


# .3 dbscan
#eps = 0.5
title             = paste("eps", eps, "MinPts", MinPts, sep=".")
data.mclust       = fpc::dbscan(cell.cell.jaccard.distance, eps = eps, MinPts = MinPts,  method = "dist", showplot = FALSE)  
c_membership      = factor(paste("cluster",data.mclust$cluster ,sep=""))
if(levels(c_membership)[1]=="cluster0"){levels(c_membership)[1] = "singleton"}
table(c_membership)

#if a cluster smaller than 5% of the total cell number, we call it a rare cell types cluster.
cell.num = dim(ExprM.RawCounts)[2] * 0.05   #cell.num #[1] 125.45
rare.cells.list.all = list()
for(c in levels(c_membership))
{
  list = rownames(cell.cell.jaccard.distance)[which(c_membership == c)]; 
  if(length(list) < cell.num & c!="singleton"){
    rare.cells.list.all[[c]]     =  list;
  }
}
names(rare.cells.list.all)


# .4 visulization using tsne with euclidean distance
ExprM.forcluster            = t(ExprM.RawCounts[GeneList.final,colnames(cell.cell.jaccard.distance)])  #make gene as cols, cell as rows
ExprM.forcluster.log2       = log2(ExprM.forcluster+0.001)
euclidean_dist_matrix       = dist(ExprM.forcluster.log2, method = "euclidean")
perplexity = 30
seed = 10
set.seed(seed) # Set a seed if you want reproducible results
Rtsne_map <- Rtsne(euclidean_dist_matrix, is_distance = TRUE, pca = FALSE,  max_iter = 3000) #the result is idependent with max_iter
pdf(file=paste("figures/", exprimentID,"_tsne_plot_euclidean_jaccard_c_membership.pdf", sep=""), width = 8, height =8, useDingbats = FALSE)
plot(Rtsne_map$Y[,1],Rtsne_map$Y[,2],col=mycols[as.integer(c_membership)], pch=16, xlab="tSNE_1", ylab="tSNE_2", cex=1, main="")
legend('topleft',levels(as.factor(c_membership)),fill=mycols, bty='n', cex=1.5)
dev.off() 


#jarccard distance for visualization
#for(seed in 1:10){
seed=10
perplexity = 30
set.seed(seed)# Set a seed if you want reproducible results
Rtsne_map <- Rtsne(cell.cell.jaccard.distance, is_distance = TRUE, pca = FALSE,  max_iter = 3000)       #the result is idependent with max_iter
pdf(file=paste("figures/", exprimentID,"_",seed,"_tsne_plot_jaccard_jaccard_c_membership.pdf", sep=""), width = 8, height =8, useDingbats = FALSE)
plot(Rtsne_map$Y[,1],Rtsne_map$Y[,2],col=mycols[as.integer(c_membership)], pch=16, xlab="tSNE_1", ylab="tSNE_2", cex=1, main="")
legend('topleft',levels(as.factor(c_membership)),fill=mycols, bty='n', cex=1.5)
dev.off() 
#}


# .5 save results
Rtnse_coord2 <-  as.data.frame(Rtsne_map$Y)
rownames(Rtnse_coord2) = rownames(cell.cell.jaccard.distance)
colnames(Rtnse_coord2) = c("dim1", "dim2")
write.table(Rtnse_coord2, file=paste("results/", exprimentID,"_Rtnse_coord2.csv", sep=""), sep=",", row.names = TRUE, col.names = TRUE)
save(ExprM.RawCounts.filter, rare.cells.list.all, file=paste("results/", exprimentID,"_forDE.RData",sep=""))

#note, for tSNE visualization, log2.euclidean is better than log2.scale.euclidian and log2.mahalanobis
#check which cell are belong to cluster2 
rare.cells.list.all[["cluster2"]]




