
#########################################################
### I) MAST figures
#########################################################

for(rare.cluster in names(rare.cells.list.all) ){

# .1 vennplot plot 
load(paste("results/", exprimentID,"_",rare.cluster,"_MIST.RData", sep=""))

# .2 overlap fisher.test
rownames(cluster_MIST.r) = cluster_MIST.r$Gene
cluster_MIST.r$log2fold_change = as.numeric(as.character(cluster_MIST.r$log2fold_change)) 
cluster.diffgene <- rownames(cluster_MIST.r[cluster_MIST.r$lr.p_value < lr.p_value_cutoff  & abs(cluster_MIST.r$log2fold_change) > diff.cutoff,])
length(cluster.diffgene)
length(intersect(cluster.diffgene, GeneList.final)) #16
intersect(cluster.diffgene, GeneList.final)
area1 = length(cluster.diffgene)
area2 = length(GeneList.final)
n12   = length(intersect(cluster.diffgene, GeneList.final))
cluster.overlap <- matrix(c(n12, area1-n12 , area2-n12, dim(data.used.df)[1]-(area1+area2-n12)),  nrow = 2)
cluster.overlap
ft.pvalue = fisher.test(cluster.overlap)$p.value

# .3 VennDiagram
library(VennDiagram)
pdf(paste("figures/", exprimentID,"_",rare.cluster,"_diff_gene_overlap.pdf", sep=""), height = 6, width = 6, useDingbats = FALSE)
overlapGenes <- intersect(cluster.diffgene, GeneList.final)
grid.newpage()
draw.pairwise.venn(length(cluster.diffgene),
                   length(GeneList.final), 
                   length(overlapGenes),
                   category = c("diffgene", paste("HighGiniGenes\n",ft.pvalue)), 
                   lty = rep("blank", 2),
                   fill = c("blue","yellow"), 
                   alpha = rep(0.5, 2), 
                   cat.pos = c(0, 0),
                   cat.dist = rep(0.025, 2))
dev.off()


# .4 barplot visilization of gene expression for individual cells in orginal order .
cells.symbol.list1 = rare.cells.list.all[[rare.cluster]]
cells.symbol.list2 = setdiff(colnames(ExprM.RawCounts.filter),cells.symbol.list1)
for(genei in intersect(cluster.diffgene, GeneList.final))
{
  #genei = "Gm7102";
  x1 <- as.numeric(unlist(ExprM.RawCounts.filter[genei, cells.symbol.list1]))
  x2 <- as.numeric(unlist(ExprM.RawCounts.filter[genei, cells.symbol.list2]))
  ylim = max(c(x1,x2)) * 1.2
  pdf(paste("figures/", exprimentID, "_",rare.cluster, "_overlapgene_rawCounts_bar_plot.", genei, ".pdf", sep=""), height = 6, width = 12, useDingbats = FALSE)
  par(mfrow=c(1,2))
  barplot(x1, main = paste(genei, rare.cluster, sep=" "), ylim=c(0,ylim), col=mycols[3], xlab="", ylab="Counts/cell", width = 0.1, axisnames = FALSE, space = 1.9);
  barplot(x2, main = "others", ylim=c(0,ylim), width = 1, col=mycols[2], xlab="", axisnames = FALSE);
  dev.off()
  
}


}