#########################################################
### H) MAST analysis, identifing differential genes between rare cell types and other cells
#########################################################
#names(rare.cells.list.all)  #list of all rare cell type : 

# .1 load data
load(paste("results/", exprimentID,"_forDE.RData",sep=""))
data.used.df <- log2(ExprM.RawCounts.filter+1)
dim(data.used.df)                           # expressioin matrix of genes(rows), cells(cols), in log 2 scale

for(rare.cluster in names(rare.cells.list.all) ){
cells.symbol.list1     = rare.cells.list.all[[rare.cluster]]
cells.coord.list1      = match(cells.symbol.list1, colnames(data.used.df))                          
cells.coord.list2      = setdiff(1:dim(data.used.df)[2], cells.coord.list1)
data.1                 = data.used.df[,cells.coord.list1]
data.2                 = data.used.df[,cells.coord.list2]
mean.1                 = apply(data.1, 1, Mean.in.log2space)
mean.2                 = apply(data.2, 1, Mean.in.log2space)
mean.diff              = abs(mean.1-mean.2)
genes.list             = names(which(mean.diff> diff.cutoff))
log2fold_change        = as.data.frame(cbind(genes.list, (mean.1-mean.2)[genes.list]))
colnames(log2fold_change) = c("gene.name", "log2fold_change")
counts  = as.data.frame(cbind( data.1[genes.list,], data.2[genes.list,] ))
groups  = c(rep(rare.cluster, length(cells.coord.list1) ), rep(paste("non_", rare.cluster, sep=""), length(cells.coord.list2) ) )
groups  = as.character(groups)
data_for_MIST <- as.data.frame(cbind(rep(rownames(counts), dim(counts)[2]), melt(counts),rep(groups, each = dim(counts)[1]), rep(1, dim(counts)[1] * dim(counts)[2]) ))
colnames(data_for_MIST) = c("Gene", "Subject.ID", "Et", "Population", "Number.of.Cells")
vbeta = data_for_MIST
vbeta.fa <- FluidigmAssay(vbeta, idvars=c("Subject.ID"),
                          primerid='Gene', measurement='Et', ncells='Number.of.Cells',
                          geneid="Gene",  cellvars=c('Number.of.Cells', 'Population'),
                          phenovars=c('Population'), id='vbeta all')
vbeta.1 <- subset(vbeta.fa, ncells==1)

# .3 MAST 
layername(vbeta.1)
head(cData(vbeta.1))
zlm.output <- zlm.SingleCellAssay(~ Population, vbeta.1, method='bayesglm', ebayes=TRUE)
show(zlm.output)
coefAndCI <- summary(zlm.output, logFC=TRUE)
coefAndCI <- coefAndCI[contrast != '(Intercept)',]
coefAndCI[,contrast:=abbreviate(contrast)]
zlm.lr <- lrTest(zlm.output, 'Population')
zlm.lr_pvalue <- melt(zlm.lr[,,'Pr(>Chisq)'])
zlm.lr_pvalue <- zlm.lr_pvalue[which(zlm.lr_pvalue$test.type == 'hurdle'),]
lrTest.table <-  merge(zlm.lr_pvalue, log2fold_change, by.x = "primerid", by.y = "gene.name")
colnames(lrTest.table) <- c("Gene", "test.type", "p_value", "log2fold_change")
cluster_lrTest.table <- lrTest.table[order(lrTest.table$p_value),]

cluster_two.sample <- LRT(vbeta.1, 'Population', referent=rare.cluster)
cluster_MIST.r <- merge(cluster_lrTest.table, cluster_two.sample, by.x = "Gene", by.y = "primerid")
cluster_MIST.r <- cluster_MIST.r[,c("Gene","test.type.x","p_value","test.type.y","p.value", "log2fold_change")]
colnames(cluster_MIST.r) = c("Gene","test.type.x","lr.p_value","test.type.y","LRT.p_value", "log2fold_change")
cluster_MIST.r <- cluster_MIST.r[order(cluster_MIST.r$lr.p_value),]

#. 4 save results
write.csv(cluster_lrTest.table, file=paste("results/", exprimentID,"_",rare.cluster,"_lrTest.csv", sep=""))
write.csv(cluster_MIST.r, file=paste("results/", exprimentID,"_",rare.cluster,"_MIST.csv", sep=""))
save(cluster_MIST.r, file=paste("results/", exprimentID,"_",rare.cluster,"_MIST.RData", sep=""))


}



