### for qPCR data, clustering method will be differnet, because we use correlation as distance, instead of jacarrd distance.

# .1 load data
load(paste("results/", exprimentID,"_StatisticsTable_afterLOESS.RData",sep=""))  #"Genelist.top_pvalue" "ExprM.Stat2" 
load(paste("results/", exprimentID,"_ExprM.filter.RData", sep=""))  #"ExprM.RawCounts.filter"  "ExprM.normCounts.filter"
load(paste("results/", exprimentID,"_ExprM.RData", sep=""))  #"ExprM.RawCounts.filter"  "ExprM.normCounts.filter"
dim(ExprM.RawCounts)            
dim(ExprM.RawCounts.filter)     

# .2 correlateion based distance matrix

if(GeneList == 1)
{
  GeneList.final       = Genelist.top_pvalue
}else{
  GeneList.final       = Genelist.HighNormGini
}


ExprM.rgcc.final.log2 <- log2(ExprM.RawCounts.filter[GeneList.final,]+0.1)
dist.cor <- as.matrix(as.dist(1-cor(ExprM.rgcc.final.log2)))
cell.cell.cor.distance = as.data.frame(dist.cor+0.01)

title             = paste("eps",eps,sep=".")
data.mclust       = fpc::dbscan(cell.cell.cor.distance, eps = eps, method = "dist", showplot = FALSE) #MinPts default is 5

o_membership      = factor(paste("db_",data.mclust$cluster ,sep=""))
if(levels(o_membership)[1]=="db_0"){levels(o_membership)[1] = "Singleton"}
c_membership = o_membership
cluster_stat = as.data.frame(table(o_membership))
cluster_stat = cluster_stat[cluster_stat$o_membership != "Singleton",]
cluster_stat = cluster_stat[rev(order(cluster_stat$Freq)),]
cn = dim(cluster_stat)[1]
new_membership = paste("Cluster_", 1:cn, sep="")
cluster_stat = cbind(cluster_stat, new_membership)
for(ii in 1:cn)
{  
  levels(c_membership)[levels(c_membership) %in% cluster_stat[ii,1] ] = as.character(cluster_stat[ii,3])
}
cluster_stat = as.data.frame(table(c_membership))
cluster_ID   = as.data.frame(cbind(rownames(cell.cell.cor.distance), as.character(c_membership)))
colnames(cluster_ID) = c("Cell_ID", "GiniClust_membership")
table(cluster_ID$GiniClust_membership)

table(c_membership)



#if a cluster smaller than 5% of the total cell number, we call it a rare cell types cluster.
cell.num = dim(ExprM.RawCounts)[2] * rare_p    #cell.num #[1] 125.45
rare.cells.list.all = list()
for(c in levels(c_membership))
{
  list = rownames(cell.cell.cor.distance)[which(c_membership == c)]; 
  if(length(list) < cell.num & c!="singleton"){
    rare.cells.list.all[[c]]     =  list;
  }
}
names(rare.cells.list.all)


# .4 visulization using tsne with euclidean distance
seed = 7
set.seed(seed) # Set a seed if you want reproducible results

mycols = c("grey85", "red", "mediumblue", "yellowgreen", "gold4", "orange", "purple1", "black")  #figure_color mannual 
Rtsne_map <- Rtsne(cell.cell.cor.distance, is_distance = TRUE, pca = FALSE,  max_iter = 1000) #the result is idependent with max_iter
pdf(file=paste("figures/", exprimentID,"_", seed,"_tsne_plot_cell.cell.cor.distance_c_membership.pdf", sep=""), width = 8, height =8, useDingbats = FALSE)
plot(Rtsne_map$Y[,1],Rtsne_map$Y[,2],col=mycols[as.integer(c_membership)], pch=16, xlab="tSNE_1", ylab="tSNE_2", cex=1, main="")
legend('topleft',levels(as.factor(c_membership)),fill=mycols, bty='n', cex=1.2)
dev.off() 


mycols_2 = c("cyan", "red", "mediumblue", "cyan", "cyan", "cyan", "cyan")
pdf(file=paste("figures/", exprimentID,"_", seed,"figure3_4.pdf", sep=""), width = 8, height =8, useDingbats = FALSE)
plot(Rtsne_map$Y[,1],Rtsne_map$Y[,2],col=mycols_2[as.integer(c_membership)], pch=16, xlab="tSNE_1", ylab="tSNE_2", cex=1, main="")
legend('topleft',levels(as.factor(c_membership)),fill=mycols_2, bty='n', cex=1.2)
dev.off() 


clustering_membership_r = data.frame(cbind(rownames(cell.cell.cor.distance), as.character(c_membership)))
colnames(clustering_membership_r) = c("cell.ID","cluster.ID")
clustering_membership_r[,1] = as.character(clustering_membership_r[,1])
clustering_membership_r[,2] = as.character(clustering_membership_r[,2])
write.csv(clustering_membership_r, file=paste("results/", exprimentID,"_clusterID.csv", sep=""))

# .5 save results
Rtnse_coord2 <-  as.data.frame(Rtsne_map$Y)
rownames(Rtnse_coord2) = rownames(cell.cell.cor.distance)
colnames(Rtnse_coord2) = c("dim1", "dim2")
write.table(Rtnse_coord2, file=paste("results/", exprimentID,"_Rtnse_coord2.csv", sep=""), sep=",", row.names = TRUE, col.names = TRUE)
save(ExprM.RawCounts.filter, rare.cells.list.all, file=paste("results/", exprimentID,"_forDE.RData",sep=""))


