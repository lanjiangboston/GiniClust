

ExprM.log2<- read.table(file="data/MASC.ISC.others.283.1963.csv",sep=",",row.names = 1,header = TRUE)
dim(ExprM.log2) #283 1963
ExprM.Nor = as.data.frame(2 ^ ExprM.log2 - 1); ##since ExprM is in log2 scale, need to transform back to normal scale, and -1 is important 
ExprM.RawCounts  = ExprM.Nor
ExprM.normCounts = ExprM.Nor 
write.table(ExprM.RawCounts, file=paste("results/", exprimentID, "_rawCounts.csv", sep=""), sep=",", row.names = TRUE, col.names = TRUE, quote=FALSE)
write.table(ExprM.normCounts, file=paste("results/", exprimentID, "_normCounts.csv", sep=""), sep=",", row.names = TRUE, col.names = TRUE, quote=FALSE)
save(ExprM.RawCounts, ExprM.normCounts, file=paste("results/",exprimentID, "_ExprM.RData",sep=""))



