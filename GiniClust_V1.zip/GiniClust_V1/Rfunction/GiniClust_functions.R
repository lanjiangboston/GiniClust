#########################################################
### D) some R function
#########################################################

calcul.gini = function(x, unbiased = TRUE, na.rm = FALSE){
  if (!is.numeric(x)){
    warning("'x' is not numeric; returning NA")
    return(NA)
  }
  if (!na.rm && any(na.ind = is.na(x)))
    stop("'x' contain NAs")
  if (na.rm)
    x = x[!na.ind]
  n = length(x)
  mu = mean(x)
  N = if (unbiased) n * (n - 1) else n * n
  ox = x[order(x)]
  dsum = drop(crossprod(2 * 1:n - n - 1,  ox))
  dsum / (mu * N)
}

jaccard <- function(m) {
    ## common values:
    A = tcrossprod(m)
    ## indexes for non-zero common values
    im = which(A > 0, arr.ind=TRUE)
    ## counts for each row
    b = rowSums(m)

    ## only non-zero values of common
    Aim = A[im]

    ## Jacard formula: #common / (#i + #j - #common)
    J = sparseMatrix(
          i = im[,1],
          j = im[,2],
          x = Aim / (b[im[,1]] + b[im[,2]] - Aim),
          dims = dim(A)
    )

    return( J )
}

Mean.in.log2space=function(x) {   #input is a vetor in log2 space, the return is their mean in log2 space.
  return(log2(mean(2^(x)-1)+1))
}



