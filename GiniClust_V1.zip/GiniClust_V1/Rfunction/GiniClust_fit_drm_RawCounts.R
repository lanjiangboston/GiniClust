#########################################################
### F) generate statistics table and fitting,  need pakcages drc.
#########################################################
#input: ExprM.RawCounts.filter 

# .1 load data
load(paste("results/", exprimentID, "_ExprM.filter.RData", sep=""))
dim(ExprM.RawCounts.filter)

library("drc")

#ExprM.RawCounts.filter = ExprM.RawCounts.filter[Maxs > 2^max.low.cutoff & Maxs < 2^max.high.cutoff,] 
Maxs          = apply(ExprM.RawCounts.filter,1,max)
Gini          = apply(as.data.frame(ExprM.RawCounts.filter), 1, function(x){calcul.gini(as.numeric(x)) } )    #theoretically, gini have very low chance to have a 1 value
log2.Maxs     = log2(Maxs+0.001)
ExprM.Stat1   = as.data.frame(cbind(Maxs,Gini,log2.Maxs))
colnames(ExprM.Stat1) = c("Maxs","Gini","log2.Maxs")
ExprM.Stat1 = ExprM.Stat1[ExprM.Stat1$log2.Maxs>log2.expr.cutoffl & ExprM.Stat1$log2.Maxs<log2.expr.cutoffh ,]  # is this necessary?
xall = ExprM.Stat1$log2.Maxs
yall = ExprM.Stat1$Gini


# .3 fitting in max-gini space 
fit.cutoffl = unname(quantile(xall, c(x.cutl, x.cuth))[1]) 
fit.cutoffh = unname(quantile(xall, c(x.cutl, x.cuth))[2]) 

# .4 diagnosis plot
pdf(paste("figures/",file_pre,"_histogram of Maxs.pdf", sep=""), width=8, height=6)
par(mfrow=c(1,2), las=2, cex=1.2)
hist(xall, breaks=1000,xlab="log2.max")
abline(v=fit.cutoffl, col="red")
abline(v=fit.cutoffh, col="red")
hist(yall, breaks=1000,xlab="Gini")
dev.off()

ExprM.Stat1.fit = ExprM.Stat1[ExprM.Stat1$log2.Maxs> fit.cutoffl & ExprM.Stat1$log2.Maxs< fit.cutoffh,]  #ExprM.Stat1.fit is a subset of ExprM.Stat1, defined by fit.cutoffl and fit.cutoffh.
x.fit = ExprM.Stat1.fit$log2.Maxs
y.fit = ExprM.Stat1.fit$Gini
Gini.drm.fit = drm(y.fit~x.fit, data = ExprM.Stat1, fct = LL.2(), type = "binomial")
j2 = order(xall)
Gini.drm.precit <- predict(Gini.drm.fit, data.frame(xall[j2]))
Normlized.Gini.Score2 = yall[j2] - Gini.drm.precit
Gini.pvalue  = pnorm(-abs(scale(Normlized.Gini.Score2, center=TRUE,scale=TRUE)))
ExprM.Stat2  = cbind(ExprM.Stat1[j2,], Gini.drm.precit, Normlized.Gini.Score2, Gini.pvalue)
ExprM.Stat2  = ExprM.Stat2[order(ExprM.Stat2$Gini.pvalue),]
Genelist.top_pvalue = rownames(ExprM.Stat2[ExprM.Stat2$Gini.pvalue < Gini.pvalue_cutoff & ExprM.Stat2$Normlized.Gini.Score2 > 0,])
length(Genelist.top_pvalue)
#Genelist.top_pvalue
#Genelist.HighNormGini 

pdf(paste("figures/", file_pre, "_smoothScatter.pdf", sep=""), width=6, height=6)
smoothScatter(xall, yall, nrpoints = 0, xlab ="log2( Max Expression Level )", ylab = "Gini", main=paste("Gene num=",length(Genelist.top_pvalue),"\npvalue=",Gini.pvalue_cutoff,sep=""), nbin = 256, ylim=c(0,1), xlim=c(0,max(xall)))
points(ExprM.Stat2[Genelist.top_pvalue,]$log2.Maxs, ExprM.Stat2[Genelist.top_pvalue,]$Gini, col="red", pch=19)
lines(xall[j2], Gini.drm.precit, col="yellow",lwd=3)
abline(v=fit.cutoffl, col="red")
abline(v=fit.cutoffh, col="red")
dev.off()

pdf(paste("figures/", file_pre, "_histogram of Nomlized.Gini.Socre2.pdf", sep=""), width=12, height=8)
par(mfrow=c(1,2), las=2, cex=1.2)
hist(Normlized.Gini.Score2, breaks=100)
hist(0-log10(Gini.pvalue), breaks=100, main=paste("Histogram of -log10(Gini.pvalue)", "\ncutoff=",Gini.pvalue_cutoff, "\n Gene num=", length(Genelist.top_pvalue), sep=""))
abline(v=0-log10(Gini.pvalue_cutoff), col="red")
dev.off()

############ .6 save results
write.table(ExprM.Stat2, file=paste("results/", exprimentID,"_StatisticsTable_afterLOESS.csv", sep=""), sep=",", row.names = TRUE,  col.names = TRUE,  quote = FALSE) 
save(Genelist.top_pvalue, ExprM.Stat2, file=paste("results/", exprimentID,"_StatisticsTable_afterLOESS.RData",sep=""))



