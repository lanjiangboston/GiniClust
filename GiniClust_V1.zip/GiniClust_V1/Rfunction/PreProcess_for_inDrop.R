#########################################################
### download data and preprocess 
#########################################################
## data process before GINICLUST
#  wget ftp://ftp.ncbi.nlm.nih.gov/geo/samples/GSM1599nnn/GSM1599495/suppl/GSM1599495_ES_d0_biorep_techrep1.csv.bz2
#  bzip2 -d GSM1599495_ES_d0_biorep_techrep1.csv.bz2
#  note: files larger than 100M in this script are not uploaded to Github 

if(!file.exists("data/GSM1599495_ES_d0_biorep_techrep1.csv"))
{
  system("wget ftp://ftp.ncbi.nlm.nih.gov/geo/samples/GSM1599nnn/GSM1599495/suppl/GSM1599495_ES_d0_biorep_techrep1.csv.bz2 -P data/")
  system("bzip2 -d data/GSM1599495_ES_d0_biorep_techrep1.csv.bz2")
}

ExprM.RawCounts <- read.delim("data/GSM1599495_ES_d0_biorep_techrep1.csv", sep=",", head=F)    #raw data
title=c("Symbol");
for(i in 2:ncol(ExprM.RawCounts)){
  title=c(title,paste(exprimentID, ".Cell_",i-1,sep=""))
};
  colnames(ExprM.RawCounts)=title
  rownames(ExprM.RawCounts)=ExprM.RawCounts[,1]
  ExprM.RawCounts= ExprM.RawCounts[,-1]
colsum <- apply(ExprM.RawCounts,2,sum)
ExprM.normCounts <- t(t(ExprM.RawCounts)*CountsForNormalized/colsum)
write.table(ExprM.RawCounts, file=paste("results/", exprimentID, "_rawCounts.csv", sep=""), sep=",", row.names = TRUE, col.names = TRUE, quote=FALSE)
write.table(ExprM.normCounts, file=paste("results/", exprimentID, "_normCounts.csv", sep=""), sep=",", row.names = TRUE, col.names = TRUE, quote=FALSE)
save(ExprM.RawCounts, ExprM.normCounts, file=paste("results/",exprimentID, "_ExprM.RData",sep=""))
