#########################################################
### C) download data and preprocess 
#########################################################

# #data process before GINICLUST
# data.TPM =read.table("../GBM.gene.count.matrix", head=TRUE,sep="\t") #default for data table is row is genes, col is cells.
# rownames(data.TPM)=data.TPM[,1]
# data.TPM=data.TPM[,-1]
# colnames(data.TPM) = c(make.unique(rep("MGH26",192)),make.unique(rep("MGH28",96)),make.unique(rep("MGH29",96)),make.unique(rep("MGH30",96)),make.unique(rep("MGH31",96)),make.unique(rep("CSC6",96)),make.unique(rep("CSC8",96)),"P.MGH26","P.MGH28","P.MGH29","P.MGH30","P.MGH31","P.MGH26GSC","P.MGH28GSC","P.MGH31GSC","P.MGH26DGC","P.MGH28DGC","P.MGH31DGC")
# #data.used = data.TPM.log2[,1:768] #include CSC6, CSC8
# data.used = data.TPM[,1:576] #exclude CSC6, CSC8, only include primary tumor single cell
# dim(data.used) #[1] 23228   576
# write.table(data.used, file = "results/GBM_primary_TPM.csv", sep=",", row.names = TRUE, col.names = TRUE, quote = FALSE)

# ExprM.RawCounts  <- read.delim("data/GBM_primary_TPM.csv", sep=",", head=T)    #TPM is got from RSEM
# ExprM.normCounts <- ExprM.RawCounts  #may update from HT-count results
# write.table(ExprM.RawCounts, file=paste("results/", exprimentID, "_rawCounts.csv", sep=""), sep=",", row.names = TRUE, col.names = TRUE, quote=FALSE)
# write.table(ExprM.normCounts, file=paste("results/", exprimentID, "_normCounts.csv", sep=""), sep=",", row.names = TRUE, col.names = TRUE, quote=FALSE)
# save(ExprM.RawCounts, ExprM.normCounts, file=paste("results/",exprimentID, "_ExprM.RData",sep=""))
# 

ExprM.RawCounts  <- read.delim("data/GBM_raw_counts.csv", sep=",", head=T)
colsum <- apply(ExprM.RawCounts,2,sum)
median(colsum) #2880000
ExprM.normCounts <- t(t(ExprM.RawCounts)*CountsForNormalized/colsum)
write.table(ExprM.RawCounts, file=paste("results/", exprimentID, "_rawCounts.csv", sep=""), sep=",", row.names = TRUE, col.names = TRUE, quote=FALSE)
write.table(ExprM.normCounts, file=paste("results/", exprimentID, "_normCounts.csv", sep=""), sep=",", row.names = TRUE, col.names = TRUE, quote=FALSE)
save(ExprM.RawCounts, ExprM.normCounts, file=paste("results/",exprimentID, "_ExprM.RData",sep=""))
